This is the simple logic design that is programmed by default into the XC2C64A CPLD on the Spartan-3E Starter Kit boards.  This design implements very basic "glue logic" used to facilitate the ability to have the different configuration modes of the Spartan-3E 500E device on the board, without the various devices causing contention with each other (namely, by turning off the Chip-enable to the Platform Flash when the Mode pin jumpers are not configured to be in Master Serial mode). The design also specifies the default memory space of the Intel Strataflash that is used for configuring the 500E in BPI Up or Down modes.  

Users can use this design (in either VHDL or Verilog) as a starting point for adding more complex functionality to the CPLD on this board.  Both a Verilog and VHDL version of the design is included.  The ISE project file was set up for the Verilog design.  The .jed file included is the configuration file that can be simply programmed back into the CPLD if the user wants to return the design to the original default state.

Files included:

cpld_platflash.ise: 	an ISE project for the Verilog design flow.  Verilog users can either start here, or create their own project from scratch and add in the top.v and top_ucf.ucf files.  VHDL users will need to start a VHDL project from scratch and add in the top.hvd and top_ucf.ucf files.

original_CPLD_design.jed:	the simple design that comes pre-programmed on the new Spartan-3E Starter Kit

top.v:	the Verilog version of the simple design

top.vhd: the VHDL version of the simple design

top_ucf.ucf: the User Constraints File (used for ISE) for the simple design.

readme.txt (this file)
