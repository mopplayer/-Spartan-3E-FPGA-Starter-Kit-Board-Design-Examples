#define TESTAPP_GEN

/* $Id: tmrctr_header.h,v 1.2 2005/10/03 19:59:34 sjen Exp $ */


#include "xbasic_types.h"
#include "xstatus.h"

XStatus TmrCtrSelfTestExample(Xuint16 DeviceId, Xuint8 TmrCtrNumber);


