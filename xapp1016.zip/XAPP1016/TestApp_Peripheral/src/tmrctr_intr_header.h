#define TESTAPP_GEN

/* $Id: tmrctr_intr_header.h,v 1.2 2006/06/26 22:03:48 somn Exp $ */


#include "xbasic_types.h"
#include "xstatus.h"


XStatus TmrCtrIntrExample(XIntc* IntcInstancePtr,
                          XTmrCtr* InstancePtr,
                          Xuint16 DeviceId,
                          Xuint16 IntrId,
                          Xuint8 TmrCtrNumber);


