echo "**************************************************************"
echo "*   Creating BIN from ./spi_user_app/executable.elf"
echo "**************************************************************"
echo ""

mb-objcopy  -O  binary  -R .vectors.reset -R .vectors.sw_exception -R .vectors.interrupt -R .vectors.debug_sw_break -R .vectors.hw_exception ./spi_user_app/executable.elf  ./flash_burn/spi_user_app.b

echo ""
echo "**************************************************************"
echo "*   Binary finished -- type 'exit' to close this window now"
echo "**************************************************************"


