#define TESTAPP_GEN

/* $Id: spi_header.h,v 1.2 2007/05/18 05:45:31 svemula Exp $ */


#include "xbasic_types.h"
#include "xstatus.h"

XStatus SpiSelfTestExample(Xuint16 DeviceId);


