//-----------------------------------------------------------------------------
//
//     AVNET IS PROVIDING THIS DESIGN, CODE, OR INFORMATION "AS IS"
//     SOLELY FOR USE IN DEVELOPING PROGRAMS AND SOLUTIONS FOR
//     XILINX DEVICES.  BY PROVIDING THIS DESIGN, CODE, OR INFORMATION
//     AS ONE POSSIBLE IMPLEMENTATION OF THIS FEATURE, APPLICATION
//     OR STANDARD, AVNET IS MAKING NO REPRESENTATION THAT THIS
//     IMPLEMENTATION IS FREE FROM ANY CLAIMS OF INFRINGEMENT,
//     AND YOU ARE RESPONSIBLE FOR OBTAINING ANY RIGHTS YOU MAY REQUIRE
//     FOR YOUR IMPLEMENTATION.  AVNET EXPRESSLY DISCLAIMS ANY
//     WARRANTY WHATSOEVER WITH RESPECT TO THE ADEQUACY OF THE
//     IMPLEMENTATION, INCLUDING BUT NOT LIMITED TO ANY WARRANTIES OR
//     REPRESENTATIONS THAT THIS IMPLEMENTATION IS FREE FROM CLAIMS OF
//     INFRINGEMENT, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
//     FOR A PARTICULAR PURPOSE.
//     
//     (c) Copyright 2005 AVNET, Inc.
//     All rights reserved.
//
//-----------------------------------------------------------------------------

//***************************************************************************//
//
// File:         spi_flash_test.c
// Date:         November 10, 2005
// Created by:   Bryan Fletcher
// Description:  Test the M25P16 Flash on the Xilinx Spartan-3E Starter Board
//               
// Notes:
//***************************************************************************//

#include "xparameters.h"
#include "xbasic_types.h"
#include "xspi_l.h"
#include "SF_commands.h"

#define SCK_FASTER_THAN_20MHz 0        // Determines whether READ or FAST_READ is used

int main(void)
{
  Xuint8   send_data[16], recv_data[16];
  Xuint8   NumBytesRcvd, mfg_id, did_up, did_low, error, SF_sr;
  Xuint16  sector_select, page_select;
  Xuint16  spi_control_reg;
  Xuint32  spi_ss_reg, i, j;

  xil_printf("Serial Flash Test\n\r");
		  
  Initialize_Spi_Controller(XPAR_SPI_FLASH_BASEADDR);
  
// Readback control register and compare with expected value
//  spi_control_reg = XSpi_mGetControlReg(XPAR_SPI_FLASH_BASEADDR);
//  xil_printf("%x\n\r",spi_control_reg);
//  xil_printf("%x\n\r",INIT_CREG);


// The SPI core has an issue where SCK sometimes doesn't start up 
// immediately.  A delay is necessary.  The Block Protect (BP) bits
// are set to a known value.  When the value read back matches
// the written value, then the core is ready.
  do
  {
      SF_write_status_register (XPAR_SPI_FLASH_BASEADDR, 0x1c);
	SF_sr = SF_read_status_register(XPAR_SPI_FLASH_BASEADDR);
	//xil_printf("SF SR = : %x \n\r", SF_sr);
  }
  while(SF_sr != 0x1C);

//  SF_sr = SF_read_status_register(XPAR_SPI_FLASH_BASEADDR);
//  xil_printf("SF SR = : %x \n\r", SF_sr);

// Turn off all BP bits to make the device writable
//  do
  {
      SF_write_status_register (XPAR_SPI_FLASH_BASEADDR, 0x00);
	//SF_sr = SF_read_status_register(XPAR_SPI_FLASH_BASEADDR);
	//xil_printf("SF SR = : %x \n\r", SF_sr);
  }
//  while(SF_sr != 0x00);

//  SF_sr = SF_read_status_register(XPAR_SPI_FLASH_BASEADDR);
//  xil_printf("SF SR = : %x \n\r", SF_sr);

// Get the Manufacturer's ID
  // Set op-code to Read ID
  send_data[0] = RDID;
  // send_data[1:3] are don't care
  // transfers 1:3 are to retrieve 3 byte ID on recv_data[1:3]
  // recv_data[0] is don't care
  
  //Enable the SPI controller core
  XSpi_Set_Enable(XPAR_SPI_FLASH_BASEADDR);
  
  // Assert the select line manually to the SPI Flash
  XSpi_mSetSlaveSelectReg(XPAR_SPI_FLASH_BASEADDR, SPI_FLASH_SELECT);
  
  // Transfer the op-code and retrieve the ID
  spi_transfer(send_data, recv_data, 4);
  
  // Deselect the SPI Flash and disable the controller
  XSpi_mSetSlaveSelectReg(XPAR_SPI_FLASH_BASEADDR, SPI_NONE_SELECT);
  XSpi_mDisable(XPAR_SPI_FLASH_BASEADDR);

  mfg_id       = recv_data[1];
  did_up       = recv_data[2];
  did_low      = recv_data[3];

  xil_printf("Manufacturer Code = : %x \n\r", mfg_id);
  xil_printf("Memory Type       = : %x \n\r", did_up);
  xil_printf("Memory Capacity   = : %x \n\r", did_low);

  xil_printf("M25P16 = 20, 20, 15\n\r");

// Perform a Chip Erase
  xil_printf("\n\rChip Erase Starting\n\r");
  SF_bulk_erase(XPAR_SPI_FLASH_BASEADDR);
  xil_printf("Chip Erase Complete - verifying\n\r");


// Verify Chip Erase
  SF_start_read(XPAR_SPI_FLASH_BASEADDR, 0x00, 0x00, 0x00, SCK_FASTER_THAN_20MHz);
  error = 0;
  for (i = 0; i < SF_BYTES/16; i++)
  {
    spi_transfer(send_data, recv_data, 16);
    for (j = 0; j < 16; j++)
    {
      if(recv_data[j] != 0xFF)
      {
        xil_printf("Error at i = %x, j = %x\n\r", i,j);
        j = 16;
        i = SF_BYTES;
        error = 1;
      }
    }
  }
  if(!error)
    xil_printf("Erase verified\n\r");
  SF_end_read (XPAR_SPI_FLASH_BASEADDR);


// Write Test
  xil_printf("\n\rData being written\n\r");
  for(sector_select = 0; sector_select < SF_SECTORS; sector_select++)
    for(page_select = 0; page_select < SF_PAGES_PER_SECTOR; page_select++)
	{
      SF_start_page_program (XPAR_SPI_FLASH_BASEADDR, sector_select, page_select, 0x00);
      for (i = 0; i < SF_BYTES_PER_PAGE; i+=16)
      {
        for(j = 0; j < 16; j++)
          send_data[j]  = i + j;
        spi_transfer(send_data, recv_data, 16);
      }
      SF_end_page_program (XPAR_SPI_FLASH_BASEADDR);
    }
  xil_printf("Test Data Written; reading back\n\n\r", i);
  
  // Readback all bytes
  SF_start_read (XPAR_SPI_FLASH_BASEADDR, 0x00, 0x00, 0x00, SCK_FASTER_THAN_20MHz);
  error = 0;
  for (i = 0; i < SF_BYTES; i+=16)
  {
    spi_transfer(send_data, recv_data, 16);
    //xil_printf("%x Data read was %x\n\r",i,recv_data[0]);
    for(j = 0; j < 16; j++)
	{
      if(recv_data[j] != ((i + j) & 0xFF))
	  {
        xil_printf("Error at i = %x, j = %x\n\r", i,j);
		xil_printf("Data read was %x\n\r", recv_data[j]);
		xil_printf("Exp. data was %x\n\r", (i+j));
        j = 16;
        i = SF_BYTES;
        error = 1;
      }
    }
  }
  if(!error)
    xil_printf("Flash Test PASSED!\n\r");
  SF_end_read (XPAR_SPI_FLASH_BASEADDR);

  return 0;

}

