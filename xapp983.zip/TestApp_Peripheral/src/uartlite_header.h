#define TESTAPP_GEN

/* $Id: uartlite_header.h,v 1.1 2007/03/01 11:44:32 mta Exp $ */


#include "xbasic_types.h"
#include "xstatus.h"

XStatus UartLiteSelfTestExample(Xuint16 DeviceId);


