/*-----------------------------------------------------------------------------
//
//     AVNET IS PROVIDING THIS DESIGN, CODE, OR INFORMATION "AS IS"
//     SOLELY FOR USE IN DEVELOPING PROGRAMS AND SOLUTIONS FOR
//     XILINX DEVICES.  BY PROVIDING THIS DESIGN, CODE, OR INFORMATION
//     AS ONE POSSIBLE IMPLEMENTATION OF THIS FEATURE, APPLICATION
//     OR STANDARD, AVNET IS MAKING NO REPRESENTATION THAT THIS
//     IMPLEMENTATION IS FREE FROM ANY CLAIMS OF INFRINGEMENT,
//     AND YOU ARE RESPONSIBLE FOR OBTAINING ANY RIGHTS YOU MAY REQUIRE
//     FOR YOUR IMPLEMENTATION.  AVNET EXPRESSLY DISCLAIMS ANY
//     WARRANTY WHATSOEVER WITH RESPECT TO THE ADEQUACY OF THE
//     IMPLEMENTATION, INCLUDING BUT NOT LIMITED TO ANY WARRANTIES OR
//     REPRESENTATIONS THAT THIS IMPLEMENTATION IS FREE FROM CLAIMS OF
//     INFRINGEMENT, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
//     FOR A PARTICULAR PURPOSE.
//     
//     (c) Copyright 2005 AVNET, Inc.
//     All rights reserved.
//
//---------------------------------------------------------------------------*/

//***************************************************************************//
//
// File:         spi_user_app.c
// Date:         November 14, 2005
// Created by:   Matthew O'Meara
//               Bryan Fletcher
// Description:  Main application to be run from System RAM.  Demonstrates 
//               how to read, erase, and program SPI flash.  The sequence of
//               the program is as follows:
//                 1. Initialize devices
//                 2. Read the 16-byte string stored at the beginning of the
//                    sector M25P16_SECTOR_WITH_STRING
//                 3. Get a new 16-byte string from the user over the UART
//                 4. Program the new string to the flash
//
//                The processor must be then reset or the FPGA reloaded to see
//                the new string.  It is intended that this application be
//                bootloaded and run from external memory.
//
//***************************************************************************//

//**************** INCLUDES *************************************************//
#include "xparameters.h"
#include "xbasic_types.h"
#include "xspi_l.h"
#include "xuartlite.h"
#include "M25P16_commands.h"

//**************** CONSTANTS ************************************************//
#define M25P16_SECTOR_WITH_STRING   31
#define SCK_FASTER_THAN_20MHz       1        // Determines whether READ or FAST_READ is used

//**************** GLOBALS **************************************************//
XUartLite RS232_DCE, RS232_DTE;

unsigned char my_send[16];
unsigned char my_receive[16];

unsigned char uart_rx_buffer[1];
unsigned char user_string[16];

//**************** PROTOTYPES ***********************************************//

//***************************************************************************//
int main (void) {

  Xuint8 ReceivedCount, rx_count, rx_byte;

// *************** DEVICE INITIALIZATION *************************** //

  // SPI Controller initialization
  Initialize_Spi_Controller(XPAR_SPI_FLASH_BASEADDR);
  XSpi_mEnable(XPAR_SPI_FLASH_BASEADDR);

  // RS232 initialization
  XUartLite_Initialize(&RS232_DCE, XPAR_RS232_DCE_DEVICE_ID);
  XUartLite_Initialize(&RS232_DTE, XPAR_RS232_DTE_DEVICE_ID);

//====================================================================//
  xil_printf("\n\rSPI User Application\n\r");

  // STEP 1:  Read in string from flash, and print to UART
  //
  M25P16_start_read (XPAR_SPI_FLASH_BASEADDR, M25P16_SECTOR_WITH_STRING, 0x00, 0x00, SCK_FASTER_THAN_20MHz);
  spi_transfer(my_send, my_receive, 16);
  M25P16_end_read (XPAR_SPI_FLASH_BASEADDR);
  xil_printf("User String stored in flash =  %s\n\r", my_receive);

  // STEP 2:  Prompt user to input string on UART
  //
  xil_printf("Enter 16-byte string to be stored in flash\n\r");
  rx_count = 0;
  while(rx_count < 16)
  {
   rx_byte = XUartLite_RecvByte(STDIN_BASEADDRESS);
	XUartLite_SendByte(STDOUT_BASEADDRESS,rx_byte);
	user_string[rx_count] = rx_byte;
	rx_count++;
  }

  // Step 3:  Program this value to SDF
  //
  xil_printf("\n\rStarting sector erase\n\r");
  M25P16_sector_erase (XPAR_SPI_FLASH_BASEADDR, M25P16_SECTOR_WITH_STRING);
  xil_printf("Starting page program\n\r");
  M25P16_start_page_program (XPAR_SPI_FLASH_BASEADDR, M25P16_SECTOR_WITH_STRING, 0x00, 0x00);
  xil_printf("Starting transfer\n\r");
  spi_transfer(user_string, my_receive, 16);
  xil_printf("Ending page program\n\r");
  M25P16_end_page_program (XPAR_SPI_FLASH_BASEADDR);

  // Step 4:  Prompt the user to reload the FPGA.  The new string is then read
  //          from the SPI Flash during the next round.
  //
  xil_printf("\n\rToggle PROG_B to load program again.\n\r");  

  while(1);
  
}




