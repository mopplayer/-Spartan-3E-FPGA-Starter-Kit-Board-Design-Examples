//-----------------------------------------------------------------------------
//
//     AVNET IS PROVIDING THIS DESIGN, CODE, OR INFORMATION "AS IS"
//     SOLELY FOR USE IN DEVELOPING PROGRAMS AND SOLUTIONS FOR
//     XILINX DEVICES.  BY PROVIDING THIS DESIGN, CODE, OR INFORMATION
//     AS ONE POSSIBLE IMPLEMENTATION OF THIS FEATURE, APPLICATION
//     OR STANDARD, AVNET IS MAKING NO REPRESENTATION THAT THIS
//     IMPLEMENTATION IS FREE FROM ANY CLAIMS OF INFRINGEMENT,
//     AND YOU ARE RESPONSIBLE FOR OBTAINING ANY RIGHTS YOU MAY REQUIRE
//     FOR YOUR IMPLEMENTATION.  AVNET EXPRESSLY DISCLAIMS ANY
//     WARRANTY WHATSOEVER WITH RESPECT TO THE ADEQUACY OF THE
//     IMPLEMENTATION, INCLUDING BUT NOT LIMITED TO ANY WARRANTIES OR
//     REPRESENTATIONS THAT THIS IMPLEMENTATION IS FREE FROM CLAIMS OF
//     INFRINGEMENT, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
//     FOR A PARTICULAR PURPOSE.
//     
//     (c) Copyright 2005 AVNET, Inc.
//     All rights reserved.
//
//-----------------------------------------------------------------------------

//***************************************************************************//
//
// File:         spi_flash_test.c
// Date:         November 10, 2005
// Created by:   Bryan Fletcher
// Description:  Test the M25P16 SPI Flash on the Xilinx Spartan-3E Starter Board
//               
// Notes:
//***************************************************************************//

#include "xparameters.h"
#include "xbasic_types.h"
#include "xspi_l.h"
#include "M25P16_commands.h"

#define SCK_FASTER_THAN_20MHz 1        // Determines whether READ or FAST_READ is used

int main(void)
{
  Xuint8*  ddr_data = (Xuint8 *) XPAR_DDR_SDRAM_16MX16_MEM0_BASEADDR;
  Xuint8   send_data[16], recv_data[16];
  Xuint8   NumBytesRcvd, mfg_id, mem_type, mem_capacity, error;
  Xuint16  sector_select, page_select;
  Xuint16  spi_control_reg;
  Xuint32  spi_ss_reg, i, j;

  Initialize_Spi_Controller(XPAR_SPI_FLASH_BASEADDR);

  XSpi_mEnable(XPAR_SPI_FLASH_BASEADDR);

// Get the Manufacturer's ID
  // Send the Read ID op-code -- ignoring recv_data
  XSpi_mSetSlaveSelectReg(XPAR_SPI_FLASH_BASEADDR, SPI_FLASH_SELECT);
  send_data[0] = RDID;
  spi_transfer(send_data, recv_data, 1);

  // Get the 3-byte ID -- send_data is don't care
  spi_transfer(send_data, recv_data, 3);

  // Deselect flash
  XSpi_mSetSlaveSelectReg(XPAR_SPI_FLASH_BASEADDR, SPI_NONE_SELECT);

  mfg_id       = recv_data[0];
  mem_type     = recv_data[1];
  mem_capacity = recv_data[2];

  xil_printf("Manufacturer Code = : %x \n\r", mfg_id);
  xil_printf("Memory Type       = : %x \n\r", mem_type);
  xil_printf("Memory Capacity   = : %x \n\r", mem_capacity);

// Perform a Chip Erase
  xil_printf("\n\rChip Erase Starting\n\r");
  M25P16_bulk_erase(XPAR_SPI_FLASH_BASEADDR);
  xil_printf("Chip Erase Complete - verifying\n\r");


// Verify Chip Erase
  M25P16_start_read(XPAR_SPI_FLASH_BASEADDR, 0x00, 0x00, 0x00, SCK_FASTER_THAN_20MHz);
  error = 0;
  for (i = 0; i < M25P16_BYTES/16; i++)
  {
    spi_transfer(send_data, recv_data, 16);
    for (j = 0; j < 16; j++)
    {
      if(recv_data[j] != 0xFF)
      {
        xil_printf("Error at i = %x, j = %x\n\r", i,j);
        j = 16;
        i = M25P16_BYTES;
        error = 1;
      }
    }
  }
  if(!error)
    xil_printf("Erase verified\n\r");
  M25P16_end_read (XPAR_SPI_FLASH_BASEADDR);


// Write Test
  xil_printf("\n\rData being written\n\r");
  for(sector_select = 0; sector_select < M25P16_SECTORS; sector_select++)
    for(page_select = 0; page_select < M25P16_PAGES_PER_SECTOR; page_select++)
	{
      M25P16_start_page_program (XPAR_SPI_FLASH_BASEADDR, sector_select, page_select, 0x00);
      for (i = 0; i < M25P16_BYTES_PER_PAGE; i+=16)
      {
        for(j = 0; j < 16; j++)
          send_data[j]  = i + j;
        spi_transfer(send_data, recv_data, 16);
      }
      M25P16_end_page_program (XPAR_SPI_FLASH_BASEADDR);
    }
  xil_printf("Test Data Written; reading back\n\n\r", i);
  
  // Readback all bytes
  M25P16_start_read (XPAR_SPI_FLASH_BASEADDR, 0x00, 0x00, 0x00, SCK_FASTER_THAN_20MHz);
  error = 0;
  for (i = 0; i < M25P16_BYTES; i+=16)
  {
    spi_transfer(send_data, recv_data, 16);
    //xil_printf("%x Data read was %x\n\r",i,recv_data[0]);
    for(j = 0; j < 16; j++)
	{
      if(recv_data[j] != ((i + j) & 0xFF))
	  {
        xil_printf("Error at i = %x, j = %x\n\r", i,j);
		xil_printf("Data read was %x\n\r", recv_data[j]);
		xil_printf("Exp. data was %x\n\r", (i+j));
        j = 16;
        i = M25P16_BYTES;
        error = 1;
      }
    }
  }
  if(!error)
    xil_printf("Flash Test PASSED!\n\r");
  M25P16_end_read (XPAR_SPI_FLASH_BASEADDR);

  // Disable the SPI Controller
  XSpi_mDisable(XPAR_SPI_FLASH_BASEADDR);

  return 0;

}

