#define TESTAPP_GEN

/* $Id: spi_header.h,v 1.2 2005/10/01 00:40:10 sjen Exp $ */


#include "xbasic_types.h"
#include "xstatus.h"

XStatus SpiSelfTestExample(Xuint16 DeviceId);


