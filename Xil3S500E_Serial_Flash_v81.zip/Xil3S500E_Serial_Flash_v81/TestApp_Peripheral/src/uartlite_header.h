#define TESTAPP_GEN

/* $Id: uartlite_header.h,v 1.2 2005/09/30 01:08:40 sjen Exp $ */


#include "xbasic_types.h"
#include "xstatus.h"

XStatus UartLiteSelfTestExample(Xuint16 DeviceId);


